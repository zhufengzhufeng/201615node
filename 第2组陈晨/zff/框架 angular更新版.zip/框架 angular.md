#### 框架 angular  
我们写好代码，框架帮我们调用，强约束按照人家的规范来写代码

 > Angular 的核心是MVC（指Model View Controller） 、模块化、双向数据绑定、指令

>AngularJS 是一个 JavaScript 框架。它是一个以 JavaScript 编写的库。
>AngularJS 是以一个 JavaScript 文件形式发布的，可通过 script 标签添加到网页中：
```
<script src="node_modules/angular/angular.js"></script>
```
#####  一 、MVC
 单向，用户改变视图(表单元素)，更改后会触发控制器，获取数据后，在刷新视图
- model(数据)
- view (视图)
- controller (控制器)
![Alt text](./B6{}EYHYW6KQRH_V]`PG5.png)
##### 二 、 MVVM  （双向数据绑定）
- model
- view
- viewModel (视图模型)
- 一但建立双向绑定，当使用者输入，会由Angular自动传到一个变量中，再自动读到所有绑到它的内容，更新它，效果上就是立即的资料同步， 在程序中修改变量，也会直接反应到呈现的外观上。（例：表单）
```
<input type="text" ng-model="name"> // ng-model只能放变量
{{name}}//表达式是一个 AngularJS 数据绑定表达式。
// AngularJS 中的数据绑定，同步了 AngularJS 表达式与 AngularJS 数据。
****{{name}} 是通过 ng-model="name" 进行同步。****
```
>1 、{{name}}//表达式
>表达式 可以支持赋值运算，可以写三元运算符，可以运算变量+-*/
> {{name?name:'hello zfpx'}}  //写三元运算符
>-  但是表达式{{}}有闪烁问题 ？
		+  解决某个变量闪烁问题：ng-bind
		+  例如：	```
					<span ng-bind="name?name:'hello zfpx'"></span>
						```
		+  ng-bind等价于{{}}，{{}}是ng-bind的简写
		+ 解决成段代码的闪烁问题 先让带有ng-cloak的标签隐藏，当数据编译好后会自动移除掉ng-cloak属性

#####三 、 模块化
创建的步骤：
1 创建一个 module
		> angular.module('[modulesName]',[],par);
			① '[modulesName]':模块的名字
			② []：模块的依赖（默认写[]）
			③par:配置函数（可以不写）	
			
	 appModule：代表的是当前模块					 
	 var appModule=angular.module('ffModules',[]);


2 创建控制器
```
 appModule.controller('[constrName]',['$scope',function ($scope) {
		  $scope.value='div1value';
		 	}])
```
> ①'[constrName]':控制器的名字	
> ②函数控制器的一个定义 会自带一个 参数$scope ===viewModel不能更改
> ③ $scope.value='div1value';	给视图绑定数据
> ④ ['$scope',fn] :[]为了防止压缩 采用数组的形式 ，一一对应

```
app.run(['$rootScope',function ($rootScope) {
        $rootScope.eat = '吃'
    }]);
```
> angular启动时会调用run方法，写了ng-app就开始执行
 **** $rootScope 是全局性的****
其他的控制器没有的属性，也可调用  $rootScope里面的属性
这样就存在一个作用域的问题：
	+  如果当前没有可以向上找,父子关系可以继承,控制器可以嵌套
			
3 创建视图	
```
1 、<html lang="en" ng-app="zfModule"> 指定启动的模块是zfModule
```
```
2 、<div ng-controller="firstC">{{value}}</div>  
ng-controller="firstC"    ---->控制器的作用范围和标签的范围相同
```	
```
3 、 数组型的
<!--{{arr}} =>  ul>li*5-->
<!--要循环谁 就写在谁的身上                $event事件源-->
<input type="text" ng-keyup="addNumber($event)" ng-model="n">
<ul>
    <!--ng-repeat="变量(数组中的value值) in 数据中" $index 索引（只要是数组 就通过索引来遍历）-->
    <li ng-repeat="a in arr track by $index">{{a}}</li>
</ul>
<script src="node_modules/angular/angular.js"></script>
<script>
    //angular的核心是数据，数据更改视图会自动刷新
    var app = angular.module("appModule",[]);
    app.controller('myCtrl',["$scope",function ($scope) {
        $scope.arr = [1,2,3];
        $scope.addNumber = function (e) { //添加数字
            var keyCode = e.keyCode; //判断keycode
            if(keyCode == 13){
                $scope.arr.unshift($scope.n);
                $scope.n = '';
            }
        }
    }]);
</script>
```

```
4、 对象数据型
<!--{{foods[0].name}}  [{name:1}]-->
    <ul class="list-group">
        <!--遍历时会产生作用域，如果不产生？-->
        <!--(key,value) in arrs 这个key是我们显示声明出来的 $index是angular提供给我们的-->
        <li class="list-group-item" ng-repeat="(parent,food) in foods track by parent">
            <div class="text-danger h2">{{$index+1}} {{food.name}}</div>
            <ul class="list-group">
                <li class="list-group-item text-center" ng-repeat="(child,a) in food.type track by child">
                    {{parent+1}}.{{$index+1}} {{a}}
                </li>
            </ul>
        </li>
    </ul>
    <ul>
        <li ng-repeat="(key,o) in obj">{{key}}:{{o}}</li>
    </ul>
</div>
<script src="node_modules/angular/angular.js"></script>
<script>
    var app = angular.module('appModule',[]);
    app.controller('myCtrl',['$scope',function ($scope) {
        $scope.foods = [
            {name:'馒头',type:["糯米的","苞米面","白面的"]},
            {name:'蔬菜类',type:["白菜","辣椒"]}
        ];
        $scope.obj = {name:'zfpx',age:8,address:'回龙观'}
    }]);

</script>

```
#### 四 、指令
**指令分为两类 自带指令  自定义指令**

**自带指令**
##### 1 、ng-app
```
html ng-app="appModule"
```
会产生一个根作用域$rootScope,让angular启动,可以指定模块名,告诉angular以当前模块来启动
###### 2 、声明模块
一切从模块开始
```
var app = angular.module("appModule",[]);
```
######  3 、 ng-model
实现双向数据绑定,放在表单元素上
```
ng-model="name"
```
M->V:将name(作用域上定义的内容)代表的值放到输入框内
V->M:如果修改输入框中的内容，可以改变作用域上name的值

> 如果写的格式是ng-model="person.name",并且person不存在会声明一个对象

##### 4 、ng-bind
取值和{{}}作用一致,可以解决闪烁单行问题

- 赋值，三元，运算

##### 5 、ng-cloak
解决多行闪烁问题
```
<style>
    [ng-cloak]{display:none}
</style>
<div ng-cloak></div>
```

##### 6 、 ng-事件 
事件，在angular可以通过ng-事件来执行作用域上的方法，如果需要事件源，需要手动传递$event对象

##### 7 、 ng-controller
会产生一个作用域，作用范围和DOM平齐，可以嵌套控制器，子可以继承父亲。不要操作DOM
```
<div ng-controller="myCtrl"></div>
app.controller('myCtrl',['$scope',function($scope){}])
```

##### 8、 run方法
写了ng-app会默认调用run方法,一般定义全局共有的变量
```
app.run(['$rootScope',function($rootScope){}]);
```

##### 9、 ng-repeat
可以遍历数组或对象,遍历谁，写在谁的身上
```
<div ng-repeat="(key,value) in arrs track by key"></div>
$scope.arrs = [{name:1},{name:2}]
```
#####10、..as ....for ....in
格式：程序员看到的 as  客户端看到的 for 单个 in 多个(angular 推荐的)
```
<select ng-model="sel" ng-options="dis.value as dis.name for dis in discount"></select>
这样给option赋初始值的时候就可以写number类型的值即：
 $scope.sel = 0.2; 
```
##### 11、ng-model-options='{      }'
```
1、	<input type="text" ng-model="query" ng-model-options="{debounce:1000}">
ng-model-options="{debounce:1000}"   延迟1s刷新数据  数据确定下来之后执行

2、	<input type="text" ng-model="query" ng-model-options="{updateOn:'blur'}">
ng-model-options="{updateOn:'blur'}"   失去焦点刷新数据
```
##### 12、 ng-disabled
```
 <button    ng-disabled="product.productCount==1">-</button>
 当数量为1的时候减号就失效，不在减少 
```
##### 13 、ng-readyonly
```
 <input type="text"   ng-readonly="true">
 设置表单为只读
```
#####$sce.trustAsHtml(input.toString())
```
//在过滤器中使用angular自带的方法
    app.filter('asHtml',function ($sce) {
        return function (input) {

            return $sce.trustAsHtml(input.toString()); //将页面的数据转换成了html内容
        }
    });    
```
**跟其一起使用的是	ng-bind-html** 
```
<td ng-bind-html="score.english | tableRed:query | asHtml"></td>
```
**这里只能放字符串类型的,将数据html编译成$sce.trustAsHtml(html)**

**创建自定义指令**
> 装饰型指令 赋予标签一些功能  link函数
 >   组件式 把标签 替换成一个组件 template
 + 指令分为四种格式
	 - Element E        <my-drag></my-drag>  元素名
	 - Attributes A     <div my-drag></div> 属性
	 - Class C             <div class="my-drag"></div> 类名
	 - Comment M     <!-- directive:myDrag -->  注释                 前后必须用空格，不建议使用   

1 、元素名创建实例 
```
<my-self></my-self>
<script>
var app=angular.module('appModule',[]);
app.directive('mySelf',function(){  //mySelf  和my-self是对应的，名字，如果有-，则按照驼峰命名规则
		return{
				replace:true,  //将原指令标签替换掉，要求模板只能有一个根节点
				restrict:'EA',  //限制使用范围 默认范围是EA,范围的标识必须大写
				 template:`<div>
                        <div>Hello</div>
                        <div>zfpx</div>
                      <!--</div>
                      <div>
                      如果有两个这样的div的时候就会报错
                      Error: [$compile:tplrt] Template for directive 'myDrag' must have exactly one root element.
                      -->

</div>
` //模板的根节点只能有一个
			
		}
})
</script>

```
2 、根据属性创建的指令
```
<div drag></div>

<script>
    var app = angular.module('appModule',[]);
    //param1 指令的名字
    //指令默认没有作用域
    app.directive('myBorder',function () {
        return {
            replace:true,
            restrict:'EA',
            //链接函数 链接视图和作用域的
            link:function ($scope,element,attrs) {//形参 ,在link函数中可以操作DOM元素
                // 1.代表的是当前指令所在的作用域
                // 2.element代表当前指令所在的标签，是一个jquery对象
                element.css('outline','5px dashed yellowgreen');
                //angular.element == $
                angular.element(document).on('click',function () {
                    alert('click')
                });
                // 3.代表当前指令上所有的属性集合
                console.log(attrs);
            }
        }
    });
</script>
```
3、类名创建指令

```
<div class="runoob-directive"></div>
<script>
var app = angular.module("myApp", []);
app.directive("runoobDirective", function() {
    return {
        restrict : "C",
        template : "<h1>自定义指令!</h1>"
    };
});
</script>
```
4、注释的创建指令
```
<!-- directive: runoob-directive -->
<script>
var app = angular.module("myApp", []);
app.directive("runoobDirective", function() {
    return {
        restrict : "M",   //限制指令声明的格式
        replace : true,
        template : "<h1>自定义指令!</h1>"
    };
});

注意： 我们需要在该实例添加 replace 属性， 否则评论是不可见的。

注意： 你必须设置 restrict 的值为 "M" 才能通过注释来调用指令。
```
> 小案例 angular写拖拽
```
 <style>
        div{width: 100px;height: 100px;position: absolute;background: -webkit-linear-gradient(top left,blue,red);top: 0;left: 0;}
    </style>
</head>
<body>
<div drag>hello</div>

<script src="node_modules/jquery/dist/jquery.js"></script>
<!--angular会判断jquery是否存在，存在的话不加载自己的js-->
<script src="node_modules/angular/angular.js"></script>
<script>
    var app = angular.module('appModule',[]);
    app.directive('drag',function () {
        return {
            restrict:'A',
            link:function (scope,element,attrs) {
                element.on('mousedown',function (e) {
                    //盒子距离鼠标的距离
                    var disX = e.pageX - $(this).offset().left;
                    var disY = e.pageY - $(this).offset().top;
                    //防止脱离焦点
                    $(document).on('mousemove',function (e) {
                        element.css({ //操作距离 大小 要加单位
                            top:e.pageY-disY,
                            left:e.pageX-disX
                        });
                    });
                    $(document).on('mouseup',function () {
                        $(document).off(); //关闭抬起和移动事件
                    });
                    e.preventDefault();
                });
            }
        }
    });
</script>
</body>
```
4、 组件化开发
组件化开发的好处，复用，管理方便统一管理

component.html
```
 <div class="container">
    <div class="row">
        <div class="col-md-12">
            <panel st="success" title="文章1">
                这是文章内容 angularjs
            </panel>
            <panel st="danger" title="文章2">
                这是第二篇文章文章内容 angularjs
            </panel>
            <panel st="warning" title="文章3">
                这是第三篇文章文章内容 angularjs
            </panel>
        </div>
    </div>
</div>
<script>
var app=angular.module('appModule',[])
app.run(function($rootScope){
	$rootScope.age='success';
});
app.directive('panel',function(){

	return{
		restrict:'E',
		templateUrl:'tmpl/panel.html',//ajax获取过来的
		link:function(scope,element,attrs){
					//自己家没有作用域   ，如果自己家有 就是自己家的作用域
					scope.name=attrs.st;
					scope.title=attrs.title;					
				}
				**scope:{}**,// 创建指令自己的独立作用域，与父级毫无关
系
				**scope:true**// 继承父级作用域并创建指令自己的作用域
				**scope:false**// 默认值，共享父级作用域
				transclude:true,//会产生一个作用域，会将指令中夹着的部分插入到带有ng-transclude的标签内
	}
})

</script>
```

tmpl/panel.html

```
<div class="panel panel-{{name}}">
    <div class="panel-heading">
        {{title}}
    </div>
    <div class="panel-body" ng-transclude>

    </div>
    <div class="panel-footer">
        <!--使用& 必须传入的是一个对象，名字和形参名相同-->
        <button ng-click="say({abc:title,b:'hello'})">点我say</button>
    </div>
</div>

```
> @ compoment.html
 >  @符号的用法

```
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <panel st="success" article="t">
                这是文章内容 angularjs
            </panel>
        </div>
    </div>
</div>
<script src="node_modules/angular/angular.js"></script>
<script>
    var app = angular.module('appModule',[]);
    app.controller('myCtrl',function ($scope) {
        $scope.t = '文章1'
    });
    app.directive('panel',function () {
        return {
            restrict:'E',
            templateUrl:`tmpl/panel.html`,
            /*link:function (scope,element,attrs) {
                scope.name = attrs.st;
                scope.title = attrs.title; //取不到属性对应的值的变量
            },*/
            scope:{ //@符引用的是字符串
                name:'@st',
                //title:'@' //名字相同可以去掉后面的
                // = 取的是变量
                title:'=article' //scope.title = $scope.t
            }, //如果通过属性传递的值 可以再scope:{} 里快速获取到
            transclude:true,
        };
    });
</script>
```
> & compoment.html  
> & 符号的用法
```
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <panel st="success" article="t" s="say(abc,b)">
                这是文章内容 angularjs
            </panel>
        </div>
    </div>
</div>
<script src="node_modules/angular/angular.js"></script>
<script>
    var app = angular.module('appModule',[]);
    app.controller('myCtrl',function ($scope) {
        $scope.t = '文章1';
        $scope.say = function (title,c) {
            alert(title);
            alert(c)
        }
    });
    app.directive('panel',function () {
        return {
            restrict:'E',
            templateUrl:`tmpl/panel.html`,
            //无法取到父级的内容，只能通过属性传递
            scope:{
                name:'@st',
                title:'=article',
                say:'&s' //取的是方法，可以直接用&符号取到
            },
            transclude:true,
        };
    });
</script>
```

> 案例  手风琴
```
<style>
        .title{background: #2b669a;width: 295px;height: 40px;line-height: 40px;text-align: center; color: #fff;position: relative}
        .title:after{content:''; display: block;height: 0;width: 0;border-width: 10px;border-color: transparent; border-left-color: #fff;  border-style: solid;position: absolute;top:10px;right:20px;}
        .content{background: #2aabd2;height: 275px;width: 295px;}
        .block{display: block}
        .none{display: none}
    </style>
</head>
<body ng-controller="myCtrl">
<!--控制div的显示和隐藏，学指令和指令之间的交互-->

<!--ng-class（动态）和class不冲突（静态）
{true:'block',false:'none'}[flag]
{block:flag,none:!flag}

    ng-show/ng-hide ng-if
    频繁切换用show/hide  操作的是样式
    一次就确定下来的内容 如果值为false内部代码不执行 操作的dom, repeat经常和if连用  if会产生一个作用域
-->
<group>
    <open title="标题1">内容1</open>
    <open title="标题2">内容2</open>
    <open title="标题3">内容3</open>
</group>
<group>
    <open title="标题1">内容1</open>
    <open title="标题2">内容2</open>
</group>
<!--将所有open的控制权交给group处理，点自己时告诉父亲 除了自己都关掉-->
<script src="node_modules/angular/angular.js"></script>
<script>
    var app = angular.module('appModule',[]);
    app.directive('group',function () {
       return {
           restrict:'E',
           controller:function ($scope) {
               var arr = [];
               //1.group中要保存所有的open的作用域  [scope,scope,scope]
               this.collectScope = function (s) {
                   arr.push(s);
               };
               //4.拿三个scope和传过来的比,如果不一样 让其他scope下的flag为false
                this.tell = function (s) {
                    arr.forEach(function (item) { //循环判断 当前传入的和item是否相等
                        if(s!=item){
                            item.flag = false;
                        }
                    });
                };
           }
       }
    });
    app.directive('open',function () {
        return {
            restrict:'E',
            require:'^group',
            templateUrl:'tmpl/open.html',
            link:function ($scope,element,attrs,oCtrl) {
                //2.将作用域传递给父亲
                oCtrl.collectScope($scope);
                //定义自己家的方法
                $scope.flag = false;
                $scope.show = function () {
                    //3.告诉父亲当前是我在点，让父亲将其他人的作用域关闭掉 oCtrl.tell(scope)
                    $scope.flag =! $scope.flag;
                    oCtrl.tell($scope)
                }
            },
            transclude:true,
            scope:{ //接收的都是属性
                tit:'@title'
            }
        }
    });
    app.controller('myCtrl',function ($scope) {})
</script>
</body>
```
> 指令找指令
```
app.directive('train',function () {
        return {
            restrict:'A',
            //^自己身上找找不到向上找
            require:'^?girl',//?是有也行，没有也行 //在当前指令上找girl，找到则会在link函数的第四个参数增加girl控制器的实例
            link:function (scope,element,attrs,gCtrl) { 则得到的值是null，否则报错
                console.log(gCtrl);
                gCtrl.collect('火车');
            }
        }
    })
```


